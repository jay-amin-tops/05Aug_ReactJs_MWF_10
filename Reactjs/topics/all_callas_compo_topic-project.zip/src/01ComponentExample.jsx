import React from 'react';

const ComponentExample = () => {
    return (
        <>
            Testing
        </>
    );
};

export default ComponentExample;